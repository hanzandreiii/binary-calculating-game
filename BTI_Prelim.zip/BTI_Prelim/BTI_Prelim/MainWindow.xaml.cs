﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;
using System.Windows.Threading;

namespace BTI_Prelim
{
    public partial class MainWindow : Window
    {
        DispatcherTimer time = new DispatcherTimer();
        private int timeout = 30;
        private CheckBox[] boxArray = new CheckBox[8];
        private int[] boxVal = new int[] {128, 64, 32, 16, 8, 4, 2, 1};
        private int mode = 0;
        private int startCon = 0;
        private int ran = 0;
        private int score = 0;
        public MainWindow()
        {
            InitializeComponent();
            boxArray = new CheckBox[] {Box_128, Box_64, Box_32, Box_16, Box_8, Box_4, Box_2, Box_1};
        }

        /// <summary>
        /// This is the method for the game mode
        /// </summary>

        private void Game_Button_Click(object sender, RoutedEventArgs e)
        {
            Game_Button.IsEnabled = false;
            Test_Button.IsEnabled = false;
            mode = 1;
        }

        /// <summary>
        /// This is the method for the test mode
        /// </summary>

        private void Test_Button_Click(object sender, RoutedEventArgs e)
        {
            Game_Button.IsEnabled = false;
            Test_Button.IsEnabled = false;
            mode = 2;
        }

        /// <summary>
        /// This is the method for the start event which is dependent on the mode
        /// </summary>
        private void Start_Button_Click(object sender, RoutedEventArgs e)
        {
            if (startCon == 0 && mode != 0)
            {
                startCon = 1;
                RanGen();
                score = 0;
                if (mode == 1)
                {
                    score = 0;
                    time.Interval = new TimeSpan(0, 0, 1);
                    time.Tick += Time_Tick;
                    time.Start();
                }
            }
            else
            {
                Game_Button.IsEnabled = true;
                Test_Button.IsEnabled = true;
                timeout = 30;
                Timer_Output.Content = timeout;
                Bin_Output.Content = "";
                Score_Output.Content = "0";
                score = 0;
                mode = 0;
                for (int x = 0; x < boxArray.Length; x++)
                    boxArray[x].IsChecked = false;
                startCon = 0;
                time.Stop();
            }
        }

        /// <summary>
        /// This is for the timer and the lose condition
        /// </summary>
        void Time_Tick(object sender, EventArgs e)
        {
            Timer_Output.Content = timeout;
            timeout--;
            if(timeout == 0)
            {
                MessageBox.Show("Game Over!");
                Start_Button_Click(sender, null);
            }
        }

        /// <summary>
        /// This generates a random number and outputs it
        /// </summary>
        private void RanGen ()
        {
            Random rng = new Random();
            ran = rng.Next(1, 256);
            Bin_Output.Content = ran.ToString();
        }

        /// <summary>
        /// This compares the number entered to the random number generated
        /// </summary>
        private void Enter_Button_Click(object sender, RoutedEventArgs e)
        {
            int ans = 0;
            for(int x = 0; x < boxArray.Length; x++)
            {
                if (boxArray[x].IsChecked == true)
                    ans += boxVal[x];
            }
            if(ans == ran)
            {
                score++;
                Score_Output.Content = score.ToString();
                if (mode == 1)
                {
                    int temp = 30 - score;
                    if (temp > 10)
                        timeout = 30 - score;
                    else
                        timeout = 10;
                }
            }
            for (int x = 0; x < boxArray.Length; x++)
                boxArray[x].IsChecked = false;
            RanGen();
        } 
    }
}
